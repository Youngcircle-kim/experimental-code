"""Optional frozen CLIP + Qwen2.5-VL integration; loaded only on request.

Official API references consulted for this implementation:
https://huggingface.co/docs/transformers/model_doc/clip
https://huggingface.co/docs/transformers/v4.57.1/en/model_doc/qwen2_5_vl
https://huggingface.co/docs/transformers/chat_templating

The repository's offline fixture tests do not execute these model weights.
Real integration must be validated with the chosen weights/device before a
research run. Images are supplied chronologically with explicit timestamps.
Option scores include every continuation token, excluding the prompt and EOS.
"""

from __future__ import annotations

import logging
from importlib.metadata import version
from typing import Any

import numpy as np

from .backends import validate_frames, validate_observations
from .config import Config
from .types import CaptionOutput, QaOutput

LOGGER = logging.getLogger(__name__)


class TransformersBackend:
    """Frozen visual/text encoders, captioner and identical frame-only QA."""

    def __init__(self, config: Config) -> None:
        """Load explicitly requested models and freeze all parameters.

        Args:
            config: Model names, revisions, device and precision settings.

        Raises:
            ImportError: Optional real-model dependencies are not installed.
            RuntimeError: The selected accelerator is unavailable.
        """
        try:
            import torch
            from PIL import Image
            from transformers import (
                AutoProcessor,
                CLIPModel,
                Qwen2_5_VLForConditionalGeneration,
            )
        except ImportError as exc:
            raise ImportError(
                "The transformers backend requires the optional 'real' "
                "dependencies. No synthetic fallback will be used."
            ) from exc
        self.config = config
        self.torch = torch
        self.image_class = Image
        self.device = torch.device(config.device)
        self.dtype = getattr(torch, config.model_dtype)
        if self.device.type == "cuda" and not torch.cuda.is_available():
            raise RuntimeError("CUDA was requested but is unavailable")
        if self.device.type == "mps" and not torch.backends.mps.is_available():
            raise RuntimeError("MPS was requested but is unavailable")
        self.clip = (
            CLIPModel.from_pretrained(
                config.encoder_model,
                revision=config.encoder_revision,
                torch_dtype=self.dtype,
                trust_remote_code=False,
            )
            .to(self.device)
            .eval()
            .requires_grad_(False)
        )
        self.encoder_commit = getattr(self.clip.config, "_commit_hash", None)
        self.clip_processor = AutoProcessor.from_pretrained(
            config.encoder_model,
            revision=self.encoder_commit or config.encoder_revision,
            trust_remote_code=False,
        )
        self.vlm: Any = None
        self.vlm_processor: Any = None
        self.vlm_commit: str | None = None
        if config.pilot != "a":
            self.vlm = (
                Qwen2_5_VLForConditionalGeneration.from_pretrained(
                    config.vlm_model,
                    revision=config.vlm_revision,
                    torch_dtype=self.dtype,
                    trust_remote_code=False,
                )
                .to(self.device)
                .eval()
                .requires_grad_(False)
            )
            self.vlm_commit = getattr(self.vlm.config, "_commit_hash", None)
            self.vlm_processor = AutoProcessor.from_pretrained(
                config.vlm_model,
                revision=self.vlm_commit or config.vlm_revision,
                min_pixels=config.vlm_min_pixels,
                max_pixels=config.vlm_max_pixels,
                trust_remote_code=False,
            )
        if config.encoder_revision == "main" or (
            self.vlm is not None and config.vlm_revision == "main"
        ):
            LOGGER.warning(
                "A model revision is 'main', which is mutable. Resolved model "
                "commits are logged; pin them in Config for subsequent runs."
            )
        self._synchronize()

    def metadata(self) -> dict[str, Any]:
        """Return reproducibility metadata for cache keys and run artifacts.

        Returns:
            Model revisions, software versions and fixed inference settings.
        """
        return {
            "backend": "transformers",
            "synthetic": False,
            "frozen": True,
            "encoder_model": self.config.encoder_model,
            "encoder_requested_revision": self.config.encoder_revision,
            "encoder_resolved_commit": self.encoder_commit,
            "vlm_model": self.config.vlm_model,
            "vlm_requested_revision": self.config.vlm_revision,
            "vlm_resolved_commit": self.vlm_commit,
            "vlm_loaded": self.vlm is not None,
            "device": str(self.device),
            "dtype": self.config.model_dtype,
            "torch_version": version("torch"),
            "transformers_version": version("transformers"),
            "caption_decoding": "greedy",
            "caption_do_sample": False,
            "caption_max_new_tokens": self.config.caption_max_new_tokens,
            "caption_prompt_version": self.config.caption_prompt_version,
            "qa_prompt_version": self.config.qa_prompt_version,
            "qa_scoring": "full-option conditional token log likelihood",
            "qa_length_normalize": self.config.qa_length_normalize,
            "qa_includes_eos": False,
            "qa_includes_event_captions": False,
            "vlm_min_pixels": self.config.vlm_min_pixels,
            "vlm_max_pixels": self.config.vlm_max_pixels,
            "clip_text_truncation": "fixed context length; warning emitted",
        }

    def _synchronize(self) -> None:
        """Wait for accelerator operations so external timings include work."""
        if self.device.type == "cuda":
            self.torch.cuda.synchronize(self.device)
        elif self.device.type == "mps":
            self.torch.mps.synchronize()

    def _require_vlm(self) -> None:
        """Reject caption or QA calls when detector-only loading was requested.

        Raises:
            RuntimeError: Pilot A intentionally omitted the caption/QA model.
        """
        if self.vlm is None or self.vlm_processor is None:
            raise RuntimeError(
                "Pilot A loads only CLIP for detector comparison. Set "
                "Config.pilot='both' to load the caption/QA model."
            )

    def _images(self, frames: np.ndarray) -> list[Any]:
        """Convert original RGB observations without extra spatial resizing.

        Args:
            frames: RGB values on the [0, 255] scale.

        Returns:
            PIL images; each model's fixed processor handles normalization.
        """
        validate_frames(frames)
        return [
            self.image_class.fromarray(np.rint(frame).astype(np.uint8))
            for frame in frames
        ]

    def _to_device(self, inputs: Any) -> dict[str, Any]:
        """Move model inputs while preserving integer token and grid indices.

        Args:
            inputs: Processor output with tensor-valued fields.

        Returns:
            Device-local input dictionary using the configured floating dtype.
        """
        moved = {
            key: value.to(
                device=self.device,
                dtype=self.dtype if value.is_floating_point() else value.dtype,
            )
            for key, value in inputs.items()
        }
        for key, value in moved.items():
            if value.is_floating_point():
                if not bool(self.torch.isfinite(value).all()):
                    raise ValueError(
                        f"Processed model input {key} is nonfinite"
                    )
                assert bool(self.torch.isfinite(value).all())
        return moved

    def _feature_array(self, features: Any, expected_rows: int) -> np.ndarray:
        """Convert projected features and validate shape and finiteness.

        Args:
            features: Projected Torch tensor.
            expected_rows: Number of frames or texts in this batch.

        Returns:
            Finite feature matrix on CPU in float64.
        """
        result = features.detach().float().cpu().numpy().astype(np.float64)
        if result.ndim != 2 or result.shape[0] != expected_rows:
            raise ValueError("Encoder returned an unexpected feature shape")
        if not np.isfinite(result).all():
            raise ValueError("Encoder returned NaN or infinite features")
        assert result.ndim == 2 and result.shape[0] == expected_rows
        assert np.isfinite(result).all()
        return result

    def encode_frames(self, frames: np.ndarray) -> np.ndarray:
        """Batch frozen CLIP visual encoding using its learned projection.

        Args:
            frames: Original RGB candidate pool, shape (N, H, W, 3).

        Returns:
            Projected finite visual features with shape (N, D).
        """
        validate_frames(frames)
        self._synchronize()
        batches: list[np.ndarray] = []
        with self.torch.inference_mode():
            for start in range(0, len(frames), self.config.encoder_batch_size):
                images = self._images(
                    frames[start : start + self.config.encoder_batch_size]
                )
                inputs = self._to_device(
                    self.clip_processor(
                        images=images,
                        return_tensors="pt",
                    )
                )
                # Explicit projection avoids get_*_features return-type changes
                # between Transformers 4 and 5.
                pooled = self.clip.vision_model(**inputs).pooler_output
                projected = self.clip.visual_projection(pooled)
                batches.append(self._feature_array(projected, len(images)))
        self._synchronize()
        result = np.concatenate(batches, axis=0)
        assert result.shape[0] == len(frames) and np.isfinite(result).all()
        return result

    def encode_visual_question(self, question: str) -> np.ndarray:
        """Place question text in the same CLIP space as visual features.

        Args:
            question: Query string, without labels or event captions.

        Returns:
            A finite projected query vector with shape (D,).
        """
        return self.encode_texts([question])[0]

    def encode_texts(self, texts: list[str]) -> np.ndarray:
        """Encode captions and questions with the identical frozen text model.

        Args:
            texts: Nonempty strings; long texts trigger a truncation warning.

        Returns:
            Projected finite CLIP text matrix with shape (N, D).
        """
        if not texts or any(not text.strip() for text in texts):
            raise ValueError("Text encoder requires nonempty input strings")
        max_length = self.clip.config.text_config.max_position_embeddings
        token_lengths = self.clip_processor.tokenizer(
            texts,
            truncation=False,
            padding=False,
            return_length=True,
        )["length"]
        if any(length > max_length for length in token_lengths):
            LOGGER.warning("CLIP text truncated to %d tokens", max_length)
        batches: list[np.ndarray] = []
        self._synchronize()
        with self.torch.inference_mode():
            for start in range(0, len(texts), self.config.encoder_batch_size):
                batch = texts[start : start + self.config.encoder_batch_size]
                inputs = self._to_device(
                    self.clip_processor(
                        text=batch,
                        return_tensors="pt",
                        padding=True,
                        truncation=True,
                        max_length=max_length,
                    )
                )
                pooled = self.clip.text_model(**inputs).pooler_output
                projected = self.clip.text_projection(pooled)
                batches.append(self._feature_array(projected, len(batch)))
        self._synchronize()
        result = np.concatenate(batches, axis=0)
        assert result.shape[0] == len(texts) and np.isfinite(result).all()
        return result

    def _prompt(self, timestamps: np.ndarray, instruction: str) -> str:
        """Render the model's chat template with chronological image markers.

        Args:
            timestamps: Exact observed timestamps in seconds.
            instruction: Fixed caption instruction or frame-only QA question.

        Returns:
            Chat-formatted text ending at the assistant generation prefix.
        """
        content: list[dict[str, str]] = []
        for timestamp in timestamps:
            content.extend(
                [
                    {
                        "type": "text",
                        "text": f"Frame at {timestamp:.6f} seconds:",
                    },
                    {"type": "image"},
                ]
            )
        content.append({"type": "text", "text": instruction})
        return str(
            self.vlm_processor.apply_chat_template(
                [{"role": "user", "content": content}],
                tokenize=False,
                add_generation_prompt=True,
            )
        )

    def _vlm_inputs(self, prompt: str, images: list[Any]) -> dict[str, Any]:
        """Process a multimodal prompt without truncating observations.

        Args:
            prompt: Chat-templated text, optionally followed by an answer.
            images: Original observations corresponding to image markers.

        Returns:
            Validated model input tensors on the configured device.

        Raises:
            ValueError: The expanded image/text sequence exceeds model context.
        """
        inputs = self._to_device(
            self.vlm_processor(
                text=[prompt],
                images=images,
                return_tensors="pt",
                padding=False,
                add_special_tokens=False,
            )
        )
        text_config = getattr(self.vlm.config, "text_config", self.vlm.config)
        context_limit = getattr(text_config, "max_position_embeddings", None)
        if context_limit and inputs["input_ids"].shape[1] > context_limit:
            raise ValueError("VLM input exceeds the configured model context")
        if inputs["input_ids"].ndim != 2 or inputs["input_ids"].shape[0] != 1:
            raise ValueError(
                "VLM processor returned an unexpected input shape"
            )
        assert inputs["input_ids"].ndim == 2
        return inputs

    def caption(
        self, frames: np.ndarray, timestamps: np.ndarray
    ) -> CaptionOutput:
        """Generate a greedy caption using only fixed observations and times.

        Args:
            frames: Question-independent chronological observations.
            timestamps: Exact observation times in seconds.

        Returns:
            Caption and actual expanded input/output token counts.
        """
        self._require_vlm()
        validate_observations(frames, timestamps)
        if len(frames) > self.config.caption_max_frames:
            raise ValueError(
                "Caption observation count exceeds fixed input budget"
            )
        self._synchronize()
        prompt = self._prompt(timestamps, self.config.caption_prompt)
        inputs = self._vlm_inputs(prompt, self._images(frames))
        input_tokens = int(inputs["input_ids"].shape[1])
        with self.torch.inference_mode():
            output_ids = self.vlm.generate(
                **inputs,
                do_sample=False,
                num_beams=1,
                max_new_tokens=self.config.caption_max_new_tokens,
            )
        self._synchronize()
        continuation = output_ids[:, input_tokens:]
        text = self.vlm_processor.batch_decode(
            continuation,
            skip_special_tokens=True,
            clean_up_tokenization_spaces=False,
        )[0].strip()
        if not text:
            raise ValueError("Caption model returned an empty caption")
        assert continuation.ndim == 2 and continuation.shape[0] == 1
        return CaptionOutput(text, input_tokens, int(continuation.shape[1]))

    def answer(
        self,
        frames: np.ndarray,
        timestamps: np.ndarray,
        question: str,
        options: tuple[str, ...],
    ) -> QaOutput:
        """Score complete option text conditioned on selected original frames.

        Args:
            frames: Final original frames; no event captions are accepted.
            timestamps: Their chronological timestamps.
            question: Question text, without ground-truth information.
            options: Candidate answer strings, in dataset order.

        Returns:
            Deterministic argmax and all conditional option log-likelihoods.

        Raises:
            ValueError: Invalid inputs, continuation boundaries or scores.
        """
        self._require_vlm()
        validate_observations(frames, timestamps)
        if not question.strip() or len(options) < 2:
            raise ValueError("QA requires a question and at least two options")
        if any(not option.strip() for option in options):
            raise ValueError("QA options must be nonempty")
        self._synchronize()
        option_lines = "\n".join(
            f"{index + 1}. {option}" for index, option in enumerate(options)
        )
        instruction = (
            f"{self.config.qa_prompt}\nQuestion: {question}\nOptions:\n"
            f"{option_lines}\nAnswer with the full text of one option."
        )
        prompt = self._prompt(timestamps, instruction)
        images = self._images(frames)
        prompt_inputs = self._vlm_inputs(prompt, images)
        prompt_ids = prompt_inputs["input_ids"]
        prompt_length = int(prompt_ids.shape[1])
        option_scores: list[float] = []
        with self.torch.inference_mode():
            for option in options:
                # Tokenize the exact joint continuation: independently encoded
                # option tokens can differ at a BPE boundary.
                inputs = self._vlm_inputs(prompt + option, images)
                full_ids = inputs["input_ids"]
                if not self.torch.equal(
                    full_ids[:, :prompt_length], prompt_ids
                ):
                    raise ValueError(
                        "Tokenizer changed the prompt at the option boundary; "
                        "cannot score this chat template without token leakage"
                    )
                target_ids = full_ids[0, prompt_length:]
                if target_ids.numel() == 0:
                    raise ValueError("Option has no continuation tokens")
                output = self.vlm(**inputs, use_cache=False, return_dict=True)
                # Every token is predicted by the preceding position. Only the
                # continuation positions contribute; the full prompt is masked.
                logits = output.logits[0, prompt_length - 1 : -1].float()
                if logits.shape[0] != target_ids.numel():
                    raise ValueError(
                        "QA logits and continuation lengths disagree"
                    )
                log_probabilities = self.torch.log_softmax(logits, dim=-1)
                token_log_likelihood = log_probabilities.gather(
                    dim=-1,
                    index=target_ids[:, None],
                ).squeeze(-1)
                if not self.torch.isfinite(token_log_likelihood).all():
                    raise ValueError(
                        "QA produced nonfinite token log likelihoods"
                    )
                score = (
                    token_log_likelihood.mean()
                    if self.config.qa_length_normalize
                    else token_log_likelihood.sum()
                )
                option_scores.append(float(score.item()))
        self._synchronize()
        scores = np.asarray(option_scores, dtype=float)
        assert scores.shape == (len(options),) and np.isfinite(scores).all()
        return QaOutput(
            int(np.argmax(scores)),
            tuple(float(score) for score in scores),
        )
